package cpsc2150.queues;
import java.lang.*;
//James Foster

public abstract class AbsQueue <T> implements IQueue <T>{


    @Override
    public String toString(){
        String str = "";
        T val;

        //loop through the queue and adds values to string then putting value back in queue
        for(int i = 0; i < this.getSize(); i++)
        {
            //extracts value
            val = this.getNext();

            //if just adds a comma if not adding final value to string
            if(i>0)
                str += ", " + val;
            else
                str += val;

            //put value back in queue
            this.add(val);
        }
        return str;
    }
}
