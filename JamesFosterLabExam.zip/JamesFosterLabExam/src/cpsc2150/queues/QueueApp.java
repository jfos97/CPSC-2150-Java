package cpsc2150.queues;
//James Foster

import java.util.*;

public class QueueApp {
    private static final int EXIT = 4;
    public static void main(String args[])
    {
        Scanner in = new Scanner(System.in);
        IQueue q = new MyQueue<Integer>();
        int choice;
        printMenu();
        choice = Integer.parseInt(in.nextLine());
        while(choice != EXIT)
        {
            if(choice == 1)
            {
                if(q.getSize()>=100)
                    System.out.println("Queue is full.");
                else
                    addToQueue(q, in);
            }
            else if(choice == 2)
            {
                if(q.getSize()==0)
                    System.out.println("Queue is currently empty.");
                else
                    getNext(q);
            }
            else if(choice == 3)
            {
                if(q.getSize()<2)
                    System.out.println("Queue must have 2 or more values to reverse.");
                else
                    q.reverse();
            }
            else
            {
                System.out.println("That's not an option!");
            }
            System.out.println("Queue is:");
            System.out.println(q.toString());
            printMenu();
            choice = Integer.parseInt(in.nextLine());
        }

    }

    /**
     * @post: The menu of options will be displayed to the user
     */
    private static void printMenu()
    {
        System.out.println("Please Select an Option");
        System.out.println("1. Add to the Queue");
        System.out.println("2. Get next number from the Queue");
        System.out.println("3. Reverse the Queue");
        System.out.println(EXIT + ". Exit");
    }

    /**
     *
     * @param q The Queue
     * @param in the Scanner object for input
     * @pre Scanner != NULL and is a valid way to get input from User
     * @post none
     */
    private static void addToQueue(IQueue q, Scanner in){
        System.out.println("What value should you add to the Queue?");
        int val = Integer.parseInt(in.nextLine());
        q.add(val);
    }

    /**
     *
     * @param q the Queue
     * @pre: none
     * @post: none
     */
    private static void getNext(IQueue q){
        System.out.println("Next value is " + q.getNext());
    }


}
