package cpsc2150.mortgages;

// James Foster
// Lab 9
// Jaf2

import java.util.Scanner;

public class MortgageView implements IMortgageView{

    private Scanner scanner = new Scanner(System.in);
    private IMortgageController controller;


    MortgageView(){}

    public void setController(IMortgageController c) {
        controller = c;
    }

    public double getHouseCost() {
        return scanner.nextDouble();
    }

    public double getDownPayment() {
        return scanner.nextDouble();
    }

    public int getYears() {
        return scanner.nextInt();
    }

    public double getMonthlyDebt() {
        return scanner.nextDouble();
    }

    public double getYearlyIncome() {
        return scanner.nextDouble();
    }

    public int getCreditScore() {
        return scanner.nextInt();
    }

    public String getName() {
        return scanner.nextLine();
    }

    public void printToUser(String s) {
        System.out.println(s);
    }

    public boolean getAnotherMortgage() {
        String clearBuff = scanner.nextLine();
        String ask = scanner.nextLine();
        if(ask.equals("Y")||ask.equals("y"))
            return true;
        else return false;
    }

    public boolean getAnotherCustomer() {
        String ask = scanner.nextLine();
        if(ask.equals("Y")||ask.equals("y"))
            return true;
        else return false;
    }

    //not needed functions...
    public void displayPayment(double p) { }
    public void displayRate(double r) { }
    public void displayApproved(boolean a) { }

}
