package cpsc2150.mortgages;

// James Foster
// Lab 9
// Jaf2

public class MortgageController implements  IMortgageController{

    private IMortgageView view;

    //constructor
    MortgageController(IMortgageView view)
    {
        this.view = view;
    }

    public void submitApplication() {

        //variables needed
        String name;
        double monthlyDebtPayments = 0, income = 0;
        int creditScore = 0, years = 0;
        double downPayment = 0, totalCost = 0;;
        int verify;
        int applyAgain = 1;
        int newCust = 1;

        //while loop to ask all questions for new customer
        while(newCust == 1) {

            //get name
            view.printToUser("Whats your name?");
            name = view.getName();

            //get income
            verify = 0;
            while (verify == 0) {
                view.printToUser("How much is your yearly income?");
                income = view.getYearlyIncome();
                if (income < 0) {
                    view.printToUser("Income must be greater than 0.");
                } else {
                    verify = 1;
                }
            }

            //get monthly debt
            verify = 0;
            while (verify == 0) {
                view.printToUser("How much are your monthly debt payments?");
                monthlyDebtPayments = view.getMonthlyDebt();
                if (monthlyDebtPayments < 0) {
                    view.printToUser("Debt must be greater than or equal to 0.");
                } else {
                    verify = 1;
                }
            }

            //get credit score
            verify = 0;
            while (verify == 0) {
                view.printToUser("What is your credit score?");
                creditScore = view.getCreditScore();
                if (creditScore < 0 || creditScore > 850) {
                    view.printToUser("Credit score must be greater then 0 and less than 850");
                } else {
                    verify = 1;
                }
            }

            //while loop to ask questions if same customer applies for more than one loan
            while (applyAgain == 1) {

                //get cost of house
                verify = 0;
                while (verify == 0) {
                    view.printToUser("How much does the house cost?");
                    totalCost = view.getHouseCost();
                    if (totalCost < 0) {
                        view.printToUser("Cost must be greater than 0.");
                    } else {
                        verify = 1;
                    }
                }

                //get down payment
                verify = 0;
                while (verify == 0) {
                    view.printToUser("How much is the down payment?");
                    downPayment = view.getDownPayment();
                    if (downPayment <=  0 || downPayment > totalCost) {
                        view.printToUser("Down payment must be greater than 0 and less than the cost of the house.");
                    } else {
                        verify = 1;
                    }
                }

                //get years of loan
                verify = 0;
                while (verify == 0) {
                    view.printToUser("How many years?");
                    years = view.getYears();
                    if (years < 0) {
                        view.printToUser("Years must be greater than 0.");
                    } else {
                        verify = 1;
                    }
                }

                //create customer and mortgage for customer
                ICustomer customer = new Customer(monthlyDebtPayments, income, creditScore, name);
                IMortgage mortgage = new Mortgage(totalCost, downPayment, years, customer);

                //print info if customer and their mortgage
                view.printToUser("Name: " + customer.getName());
                view.printToUser("Income: $" + customer.getIncome());
                view.printToUser("Credit Score: " + customer.getCreditScore());
                view.printToUser("Monthly Debt: $" + customer.getMonthlyDebtPayments());
                view.printToUser("Mortgage info:");
                view.printToUser("Principle Amount: $" + mortgage.getPrincipal());
                view.printToUser("Interest Rate: " + mortgage.getRate()*100 + "%");
                view.printToUser("Term: " + mortgage.getYears() + " years");
                view.printToUser("Monthly payment: $" + mortgage.getPayment());

                //ask if same customer wants to apply for another loan
                view.printToUser("Would you like to apply for another mortgage? Y/N");
                if (view.getAnotherMortgage())
                    applyAgain = 1;
                else
                    applyAgain = 0;
            }
            //ask if another customer wants to apply for a loan
            view.printToUser("Would you like to consider another customer? Y/N");
            if (view.getAnotherCustomer()) {
                newCust = 1;
                applyAgain = 1;
            }
            else
                newCust = 0;
        }
    }

}
