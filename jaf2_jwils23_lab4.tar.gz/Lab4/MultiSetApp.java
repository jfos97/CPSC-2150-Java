package Lab4;
/*
    James Foster
    Jordan Wilson
    CPSC 2150
    lab 4
 */

import java.lang.*;
import java.util.Scanner;

public class MultiSetApp
{

    public static void main(String[] args)
    {

        //Declaration of scanner and data variables of ISet
        Scanner scanner = new Scanner(System.in);
        String input = "\0";
        String choice = "\0";
        String choiceType = "\0";
        ISet mySet;
        ISet mySet2;

        int i=0, num =0;

        //Print menu
        System.out.println("Make a selection");
        System.out.println("1. Find the Union of two sets");
        System.out.println("2. Find the Intersection of two sets");
        System.out.println("3. Find the Difference of two sets");
        System.out.println("4. Exit");

        //check for quit
        choice = scanner.nextLine();
        while (!choice.equals("4"))
        {
            //asks UI whether to make ArraySet or listSet
            while(i!=1)
            {
                System.out.println("Enter 1 for an array implementation or 2 for list implementation");
                choiceType= scanner.nextLine();
                if(choiceType.equals("1")){i=1;}
                else if( choiceType.equals("2")){i=1;}
            }
            i=0;

            //if make array set
            if (choiceType.equals("1"))
            {
                //Array set 1
                mySet = new ArraySet();
                System.out.println("Make set 1");

                //Will loop till 'q' in read in
                while (!input.equals("q"))
                {
                    //prints menu
                    System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
                    input = scanner.nextLine();
                    if (!input.equals("q"))
                    {
                        //takes number and check for contains, then adds
                        num = Integer.valueOf(input);
                        if (mySet.contains(num)) { System.out.println("That value is already in the set");}
                        else { mySet.add(num); }
                    }
                }

                //Array set 2
                input = "\0";
                mySet2 = new ArraySet();
                System.out.println("Make set 2");

                //Will loop till 'q' in read in
                while (!input.equals("q"))
                {
                    //prints menu
                    System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
                    input = scanner.nextLine();
                    if (!input.equals("q"))
                    {
                        //takes number and check for contains, then adds
                        num = Integer.valueOf(input);
                        if (mySet2.contains(num)) { System.out.println("That value is already in the set");}
                        else { mySet2.add(num); }
                    }
                }

                //Prints sets
                System.out.println("Set 1 is: ");
                System.out.println(mySet.toString());
                System.out.println("Set 2 is: ");
                System.out.println(mySet2.toString());
            }

            //if make list set
            else
            {
                mySet = new ListSet();
                System.out.println("Make set 1");

                //Will loop till 'q' in read in
                while (!input.equals("q"))
                {
                    //prints menu
                    System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
                    input = scanner.nextLine();
                    if (!input.equals("q"))
                    {
                        num = Integer.valueOf(input);
                        if (mySet.contains(num)) {System.out.println("That value is already in the set");}
                        else {mySet.add(num);}
                    }
                }
                input = "\0";

                mySet2 = new ListSet();
                System.out.println("Make set 2");

                //Will loop till 'q' in read in
                while (!input.equals("q"))
                {
                    //prints menu
                    System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
                    input = scanner.nextLine();
                    if (!input.equals("q"))
                    {
                        //takes number and check for contains, then adds
                        num = Integer.valueOf(input);
                        if (mySet2.contains(num)) {System.out.println("That value is already in the set");}
                        else {mySet2.add(num);}
                    }
                }

                //Prints sets
                System.out.println("Set 1 is: ");
                System.out.println(mySet.toString());
                System.out.println("Set 2 is: ");
                System.out.println(mySet2.toString());
            }
            input = "\0";
            choiceType = "\0";

            //uses choice to call function for union, intersect or difference
            if (choice.equals("1"))
            {
                System.out.println("Union is:");
                mySet.union(mySet2);
                System.out.println(mySet.toString());
            }
            else if (choice.equals("2"))
            {
                System.out.println("Intersect is:");
                mySet.intersect(mySet2);
                System.out.println(mySet.toString());
            }
            else if (choice.equals("3"))
            {
                System.out.println("Difference is:");
                mySet.difference(mySet2);
                System.out.println(mySet.toString());
            }

            //prints main menu again
            System.out.println("Make a selection");
            System.out.println("1. Find the Union of two sets");
            System.out.println("2. Find the Intersection of two sets");
            System.out.println("3. Find the Difference of two sets");
            System.out.println("4. Exit");
            choice = scanner.nextLine();
        }

        // exits program when UI reads in "4"
        System.exit(0);
    }
}
