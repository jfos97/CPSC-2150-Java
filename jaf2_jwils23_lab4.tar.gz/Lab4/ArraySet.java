package Lab4;
/*
    James Foster
    Jordan Wilson
    CPSC 2150
    lab 4
 */

import java.lang.*;

public class ArraySet implements ISet
{
    private int[] array;
    private int size=0;


    /**
     *
     * @return string of values in set
     */
    @Override
    public String toString()
    {
        //add each value in array to string
        int i;
        String j = "";
        for (i=0; i<size; i++) { j = j + array[i]+", ";}
        return j;
    }

    //regular constructor
    ArraySet() { array = new int [100];}

    public void add(Integer val)
    {
        array[size] = val;
        size++;
    }

    public Integer removePos(int pos)
    {
        int num, i;

        num = array[pos];

        //move all values down one position after removing value at pos
        for(i=pos;i<size; i++)
        {
            array[i] = array[i+1];
        }
        size--;

        return num;

    }

    public boolean contains(Integer val)
    {
        int i;

        for(i=0; i<size; i++)
        {
            if(array[i]==val)
            {return true;}

        }
        return false;
    }

    public int getSize() { return size; }

}
