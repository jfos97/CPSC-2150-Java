package Lab5;
/*
    James Foster
    CPSC 2150
    lab 5
 */

import java.util.ArrayList;
import java.util.List;

public class ListSet<T> extends SetAbs<T>
{

    private List<T> lSet;


    ListSet()
    {
        lSet= new ArrayList<T>();
    }

    public void add(T val)
    {
        lSet.add(val);
    }

    public T removePos(int pos)
    {
        return lSet.remove(pos);
    }

    public boolean contains(T val)
    {
        if(lSet.contains(val)) {return true;}
        return false;
    }

    public int getSize()
    {
        return lSet.size();
    }
}
