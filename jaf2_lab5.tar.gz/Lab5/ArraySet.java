package Lab5;
/*
    James Foster
    CPSC 2150
    lab 5
 */

import java.lang.*;

public class ArraySet<T> extends SetAbs<T>
{
    private T[] array;
    private int size=0;



    //regular constructor
    ArraySet() { array = (T[]) new Object[100];}


    public void add(T val)
    {
        array[size] = val;
        size++;
    }

    public T removePos(int pos)
    {
        T num;
        int i;

        num = array[pos];

        //move all values down one position after removing value at pos
        for(i=pos;i<size; i++)
        {
            array[i] = array[i+1];
        }
        size--;

        return num;

    }

    public boolean contains(T val)
    {
        int i;

        for(i=0; i<size; i++)
        {
            if(array[i].equals(val))
            {return true;}

        }
        return false;
    }

    public int getSize() { return size; }

}
