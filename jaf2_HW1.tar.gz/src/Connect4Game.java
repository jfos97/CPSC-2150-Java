/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 1
 */

import java.util.*;



public class Connect4Game {

    public static void main(String [] args)
    {
        Scanner scanner = new Scanner((System.in));
        String clearBuff;
        int input;
        int piecesToUse = 6*7;
        GameBoard board = new GameBoard();
        System.out.println(board.toString());

        while(piecesToUse>0)
        {
            //Player X
            if(piecesToUse%2 == 0 )
            {
                System.out.println("Player X, what column do you want to place your marker in?");
                input = scanner.nextInt();
                clearBuff = scanner.nextLine();

                //verify user input
                while(input<0 || input >6)
                {
                    System.out.println("Column must be between 0 and 6");
                    System.out.println("Player X, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();
                }

                //confirm column desired is not full
                while(!board.checkIfFree(input))
                {
                    System.out.println("Column is full");
                    System.out.println("Player X, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();
                }

                board.placeToken('X', input);

                //checks for win
                if(board.checkForWin(input))
                {
                    System.out.println(board.toString());
                    System.out.println("Player X Won!");
                    String nGame;
                    int i=0;
                    //if won, asks to play again
                    while(i!=1)
                    {
                        System.out.println("Would you like to play again?  Y/N");
                        nGame = scanner.nextLine();
                        if (nGame.equals("y")||nGame.equals("Y"))
                        {
                            board = new GameBoard();
                            piecesToUse = 43;
                            i=1;
                        }
                        else if (nGame.equals("n")||nGame.equals("N"))
                        {
                            System.exit(0);
                        }
                    }
                }

                System.out.println(board.toString());
                piecesToUse--;
            }

            //Player O
            else
            {
                System.out.println("Player O, what column do you want to place your marker in?");
                input = scanner.nextInt();
                clearBuff = scanner.nextLine();

                //verviy user input
                while(input<0 || input >6)
                {
                    System.out.println("Column must be between 0 and 6");
                    System.out.println("Player O, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();
                }

                //make sure desired column isn't full
                while(!board.checkIfFree(input))
                {
                    System.out.println("Column is full");
                    System.out.println("Player O, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();
                }

                board.placeToken('O', input);

                //checks for win
                if(board.checkForWin(input))
                {
                    System.out.println(board.toString());
                    System.out.println("Player O Won!");
                    String nGame;
                    int i=0;
                    //if win then asks to play again
                    while(i!=1)
                    {
                        System.out.println("Would you like to play again?  Y/N");
                        nGame = scanner.nextLine();
                        if (nGame.equals("y")||nGame.equals("Y"))
                        {
                            board = new GameBoard();
                            piecesToUse = 43;
                            i=1;
                        }
                        else if (nGame.equals("n")||nGame.equals("N"))
                        {
                            System.exit(0);
                        }
                    }
                }
                System.out.println(board.toString());
                piecesToUse--;
            }
            //after all pieces are played, check for tie and asks to play again
            if(board.checkTie())
            {
                System.out.println("Tie game");
                System.out.println("Would you like to play again?  Y/N");
                String nGame = scanner.nextLine();
                if(nGame.equals("y")||nGame.equals("Y"))
                {
                    board = new GameBoard();
                    piecesToUse = 42;
                    System.out.println(board.toString());
                }
                else{ System.exit(0);}
            }

        }

    }
}
