/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 1
 */

import java.util.*;



public class GameBoard {
    /**
     * @invariant r >= 0 && r <= 5
     * @invariant c >= 0 && c <= 6
     * @invariant p must be 'X', 'O' or ' '
     */

    private char [][] board;

    //Constructor for game board
    public GameBoard()
    {
        int i, j;
        board = new char [6][7];
        for(i=0; i<board.length; i++)
        {
            for(j=0; j<board[i].length; j++)
            {
                board[i][j] = ' ';
            }
        }
    }

    /**
     *
     * @param c column of piece to be played
     * @return true if c is not full, false otherwise
     */
    boolean checkIfFree(int c)
    {
        int i;
        for(i=0; i<=5; i++)
        {
            if(board[i][c]==' '){return true;}
        }
        return false;
    }

    /**
     *
     * @param c column of last placed piece
     * @return true if last played piece resulted in win, false otherwise
     */
    boolean checkForWin(int c)
    {
        int row = 5;
        char p = ' ';
        //use while loop to find last placed marker in column
        while(p == ' ')
        {
            p = board[row][c];
            row--;
        }
        row+=1;

        //function calls to check for all possible wins
        if(checkDiagWin(row ,c, p))
        {return true;}
        else if(checkHorizWin(row, c, p))
        {return true; }
        else if(checkVertWin(row, c ,p))
        {return true;}
        else {return false;}


    }

    /**
     *
     * @param p is marker of last played piece
     * @param c is column of last played marker
     * @Pre checkIfFree(c)== true
     * @Post p will be the placed in the lowest free spot in column c
     *
     */
    void placeToken(char p, int c)
    {
        int i,row=0;
        //for loop to find lowest row in column to place marker
        for(i=board.length-1; i>=0; i--)
        {
            if(board[i][c]==' ') {
                row = i;
            }
        }
        board[row][c]= p;
    }

    /**
     *
     * @param r row of last played piece
     * @param c column of last played piece
     * @param p marker of last played piece
     * @return true if last played piece result in win by horizontal 4 in a row false otherwise
     */
    boolean checkHorizWin(int r, int c, char p)
    {

        for (int col = 0; col < board[r].length - 3; col++)
        {
            if (board[r][col] != ' ' && board[r][col] == board[r][col+1] &&
                    board[r][col] == board[r][col+2] && board[r][col] == board[r][col
                    +3])
            { return true; }
        }

        return false;
    }

    /**
     *
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     *
     * @return return true if the last played piece resulted in a vertical 4 in a row false otherwise
     */
    boolean checkVertWin(int r, int c, char p)
    {

            for (int row = 0; row < board.length - 3; row++)
            {
                if (board[row][c] != ' ' && board[row][c] == board[row+1][c] &&
                        board[row][c] == board[row+2][c] && board[row][c] == board[row+3][c])
                { return true;}
            }



        return false;
    }

    /**
     *
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     * @return return true if the last played piece resulted in a diagonal 4 in a row, false otherwise
     */
    boolean checkDiagWin(int r, int c, char p)
    {
        for (int row = 0; row < board.length - 3; row++)
        {
            for (int col = 0; col < board[row].length - 3; col++)
            {
                if (board[row][col] != ' ' && board[row][col] == board[row+1][col
                        +1] && board[row][col] == board[row+2][col+2] && board[row][col] ==
                        board[row+3][col+3])
                {return true; }
            }
        }
        for (int row = board.length-1; row >2; row--)
        {
            for (int col = 0; col <board[row].length-3 ; col++)
            {
                if (board[row][col] != ' ' && board[row][col] == board[row-1][col
                        +1] && board[row][col] == board[row-2][col+2] && board[row][col] ==
                        board[row-3][col+3])
                {return true;}
            }
        }
        return false;
    }

    /**
     *
     * @param r row of desired marker
     * @param c column of desired marker
     * @return marker that is at [r][c], returns ' ' if there is no marker
     */

    char whatsAtPos(int r, int c) { return board[r][c]; }

    /**
     *
     * @return string witch contain design of gameboard at current state
     */
    @Override
    public String toString()
    {
        String gBoard="";

        //column numbers
        gBoard+="|0|1|2|3|4|5|6|\n";

        //for loop to write 2d array of board to string
        for (int row = board.length-1; row >=0; row--) {
            gBoard += "|";
            for (int col = 0; col < board[row].length; col++) {
                gBoard += board[row][col] + "|";
            }
            gBoard += "\n";
        }
        return gBoard;
    }

    /**
     *
     * @return true if game ended in tie, false otherwise
     * @Pre no previous play has resulted in a win
     * @Post checkTie == true iff [there are no available spaces left on the board]
     *
     */
    boolean checkTie()
    {
        for(int i=0; i<board[0].length;i++)
        {
            if (checkIfFree(i))
            {
                return false;
            }
        }
            return true;
    }

}
