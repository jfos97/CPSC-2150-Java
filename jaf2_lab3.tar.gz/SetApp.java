/*
    James Foster
    CPSC 2150
    lab 3
 */

import java.util.*;


public class SetApp
{
    public static void main(String [] args) {

        //asks UI whether to make ArraySet or listSet
        System.out.println("Enter 1 for an array implementation or 2 for list implementation");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        if (input.equals("1"))
        {
            ArraySet arr = new ArraySet();

            //Will loop till '3' in read in
            while (!input.equals("3"))
            {
                //prints menu
                System.out.println("1. Add a value to set");
                System.out.println("2. Remove a value from the set");
                System.out.println("3. Exit");

                input = scanner.nextLine();

                while (input.equals("1"))
                {
                    System.out.println("What value to add to set?");
                    int num = scanner.nextInt();
                    input = scanner.nextLine();

                    if (arr.contains(num)) {
                        System.out.println("That value is already in the set");
                    } else { arr.add(num);}

                    System.out.println("Set is: ");
                    System.out.println(arr.toString());
                    input = "-1";

                }
                while (input.equals("2")) {
                    if (arr.getSize() == 0) {
                        System.out.println("Can not remove from empty set");
                        System.out.println(arr.toString());
                        input = "-1";
                    } else {
                        System.out.println("What position should be removed from the set?");
                        int num = scanner.nextInt();
                        input = scanner.nextLine();


                        while (arr.getSize() < num || num < 0) {
                            System.out.println("That's not a valid position");
                            System.out.println("What position should be removed from the set?");
                            num = scanner.nextInt();
                            input = scanner.nextLine();

                        }
                        arr.removePos(num);
                    }
                    System.out.println("Set is: ");
                    System.out.println(arr.toString());
                    input = "\0";
                }

            }
        } else if (input.equals("2"))
        {
            ListSet list = new ListSet();

            while (!input.equals("3")) {

                //prints menu
                System.out.println("1. Add a value to set");
                System.out.println("2. Remove a value from the set");
                System.out.println("3. Exit");
                input = scanner.nextLine();

                if (input.equals("1")) {
                    System.out.println("What value to add to set?");
                    int num = scanner.nextInt();
                    input = scanner.nextLine();


                    if (list.contains(num)) {
                        System.out.println("That value is already in the set");
                    } else {
                        list.add(num);
                    }
                    System.out.println("Set is: ");
                    System.out.println(list.toString());
                    input = "0";
                } else if (input.equals("2"))
                {
                    if (list.getSize() == 0)
                    {
                        System.out.println("Can not remove from empty set");
                        System.out.println(list.toString());
                        input = "0";
                    }
                    else {

                        System.out.println("What position should be removed from the set?");
                        int num = scanner.nextInt();
                        input = scanner.nextLine();


                        while (list.getSize() < num || num < 0) {
                            System.out.println("That's not a valid position");
                            System.out.println("What position should be removed from the set?");
                            num = scanner.nextInt();
                            input = scanner.nextLine();

                        }
                        list.removePos(num);
                        System.out.println("Set is: ");
                        System.out.println(list.toString());
                        input = "0";
                    }

                }
            }
        }
        // exits program when UI reads in "3"
        else if(input.equals("3"))
        {
            System.exit(0);
        }
    }
}
