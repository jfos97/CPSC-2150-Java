package cpsc2150.mortgages;

// James Foster
// Lab 10
// Jaf2

public class MortgageApp {
    public static void main(String [] args)
    {
        IMortgageView view = new MortgageView();
        IMortgageController controller = new MortgageController(view);
        view.setController(controller);
    }
}
