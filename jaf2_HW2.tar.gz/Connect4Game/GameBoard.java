package Connect4Game;

/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 2
 */

public class GameBoard implements IGameBoard{
    /**
     * @invariant r >= 0 && r <= 5
     * @invariant c >= 0 && c <= 6
     * @invariant p must be 'X', 'O' or ' '
     */

    private char [][] board;
    private int numToWin;

    //Constructor for game board
    public GameBoard(int row, int column, int win)
    {
        int i, j;
        this.numToWin = win;
        board = new char [row][column];
        for(i=0; i<board.length; i++)
        {
            for(j=0; j<board[i].length; j++)
            {
                board[i][j] = ' ';
            }
        }
    }

    public void placeToken(char p, int c)
    {
        int i, row=0;
        //for loop to find lowest row in column to place marker
        for(i=board.length-1; i>=0; i--)
        {
            if(board[i][c]==' ') {
                row = i;
            }
        }
        board[row][c]= p;
    }

    public boolean checkHorizWin(int r, int c, char p)
    {
        int n =0, col;

            for (col=0; col < board[r].length-1; col++)
            {
                if(whatsAtPos(r, col) ==p)
                {
                    n+=1;
                }
                else{n=0;}
                if(n==getNumToWin()){return true;}
            }
        return false;
    }

    public boolean checkVertWin(int r, int c, char p) {

        int n = 0, row ;

        for (row = r; row >= 0; row--) {
            if (whatsAtPos(row, c)==p) {
                n += 1;
            }
            else {n = 0;}
            if (n == getNumToWin()) { return true; }
        }
        return false;
    }

    public boolean checkDiagWin(int r, int c, char p) {

        int rowCheck, colCheck, n;
        //variable n is counter for how many in a row


        //nested for loop checks for bottom left to top right diagonal win
        for (int row = 0; row <= board.length - numToWin; row++) {
            for (int col = 0; col <=board[row].length - numToWin; col++) {
                if (whatsAtPos(row,col)!=' ' && whatsAtPos(row, col) == whatsAtPos(row + 1, col + 1)) {
                    n = 2;
                    rowCheck = row + 1;
                    colCheck = col + 1;

                    while (n > 0) {
                        if (whatsAtPos(rowCheck, colCheck) == whatsAtPos(rowCheck + 1, colCheck + 1)) {
                            n += 1;
                        } else {
                            n = 0;
                        }
                        if (n == getNumToWin()) {
                            return true;
                        }
                        rowCheck += 1;
                        colCheck += 1;
                    }
                }
            }
        }
        //nested for loop checks for top left to bottom right diagonal win
        for (int row = board.length - 1; row >=numToWin-1; row--) {
            for (int col = 0; col <= board[row].length - numToWin; col++) {
                if (whatsAtPos(row,col)!=' ' && whatsAtPos(row, col) == whatsAtPos(row - 1, col +1)) {
                    n = 2;
                    rowCheck = row - 1;
                    colCheck = col + 1;

                    while (n > 0) {
                        if (whatsAtPos(rowCheck, colCheck) == whatsAtPos(rowCheck - 1, colCheck + 1)) {
                            n += 1;
                        } else {
                            n = 0;
                        }
                        if (n == getNumToWin()) {
                            return true;
                        }
                        rowCheck -= 1;
                        colCheck += 1;
                    }
                }
            }

        }
        return false;

    }


    public char whatsAtPos(int r, int c) { return board[r][c]; }

    /**
     *
     * @return string witch contain design of gameboard at current state
     */
    @Override
    public String toString()
    {
        String gBoard="";

        //column numbers
        for (int col = 0; col < board[0].length; col++) {
            if(col<10)
            {
                gBoard += "| "+col;
            }
            else
            {
                gBoard += "|"+col;
            }
        }
        gBoard+="|\n";

        //for loop to write 2d array of board to string
        for (int row = board.length-1; row >=0; row--) {
            gBoard += "|";
            for (int col = 0; col < board[row].length; col++) {
                gBoard += board[row][col] + " |";
            }
            gBoard += "\n";
        }
        return gBoard;
    }

    public boolean checkTie()
    {
        //checks for any free spaces at top of board.
        for(int i=0; i<board[0].length;i++)
        {
            if (checkIfFree(i))
            {
                return false;
            }
        }
            return true;
    }

    public int getNumRows() {return board.length; }

    public int getNumColumns() {return board[0].length; }

    public int getNumToWin() {return numToWin; }
}
