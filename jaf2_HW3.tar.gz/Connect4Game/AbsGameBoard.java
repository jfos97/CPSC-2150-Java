package Connect4Game;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 3
 */

public abstract class AbsGameBoard implements IGameBoard {

    /**
     *
     * @return string witch contain design of gameboard at current state
     */
    @Override
    public String toString()
    {
        String gBoard="";

        //column numbers
        for (int col = 0; col < getNumColumns(); col++)
        {
            if(col<10) { gBoard += "| "+col; }
            else { gBoard += "|"+col; }
        }

        gBoard+="|\n";

        //for loop to write pieces on game board to string
        for (int row = getNumRows()-1; row >=0; row--)
        {
            gBoard += "|";
            for (int col = 0; col < getNumColumns(); col++) { gBoard += whatsAtPos(row, col) + " |"; }
            gBoard += "\n";
        }
        return gBoard;
    }

}
