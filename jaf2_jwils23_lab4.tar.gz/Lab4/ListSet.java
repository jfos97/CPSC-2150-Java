package Lab4;
/*
    James Foster
    Jordan Wilson
    CPSC 2150
    lab 4
 */

import java.lang.*;
import java.util.ArrayList;
import java.util.List;

public class ListSet implements ISet
{

    private List<Integer> lSet;

    /**
     *
     * @return string of values in set
     *
     */
    @Override
    public String toString()
    {
        //add each value in set to a string
        String j = "";
        j = j+lSet;
        return j;
    }

    ListSet()
    {
        lSet= new ArrayList<Integer>();
    }

    public void add(Integer val)
    {
        lSet.add(val);
    }

    public Integer removePos(int pos)
    {
        return lSet.remove(pos);
    }

    public boolean contains(Integer val)
    {
        if(lSet.contains(val))
        {
            return true;
        }
        else{return false;}
    }

    public int getSize()
    {
        return lSet.size();
    }
}
