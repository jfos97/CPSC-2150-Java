package cpsc2150.mortgages;

// James Foster
// Lab 10
// Jaf2

public class MortgageController implements  IMortgageController{

    private IMortgageView view;

    //constructor
    MortgageController(IMortgageView view)
    {
        this.view = view;
    }

    public void submitApplication() {

        //variables needed
        String name;
        double monthlyDebtPayments, income;
        int creditScore, years;
        double downPayment, totalCost;
        int verify = 0;

            //get name
        name = view.getName();

            //get income
        income = view.getYearlyIncome();
        if (income <= 0) {
            view.printToUser("Income must be greater than 0.");
            verify = 1;
        }
            //get monthly debt
        monthlyDebtPayments = view.getMonthlyDebt();
        if (monthlyDebtPayments < 0) {
            view.printToUser("Debt must be greater than or equal to 0.");
            verify = 1;
        }
            //get credit score
        creditScore = view.getCreditScore();
        if (creditScore < 0 || creditScore > 850) {
            view.printToUser("Credit score must be greater then 0 and less than 850");
            verify = 1;
        }
            //get cost of house
        totalCost = view.getHouseCost();
        if (totalCost < 0) {
            view.printToUser("Cost must be greater than 0.");
            verify = 1;
        }
            //get down payment
        downPayment = view.getDownPayment();
        if (downPayment <=  0 || downPayment > totalCost && verify!=1) {
            view.printToUser("Down payment must be greater than 0 and less than the cost of the house.");
            verify = 1;
        }
            //get years
        years = view.getYears();


        //create customer and mortgage for customer
        ICustomer customer = new Customer(monthlyDebtPayments, income, creditScore, name);
        IMortgage mortgage = new Mortgage(totalCost, downPayment, years, customer);

            //confirms that verify didn't change indicating a problem
            //then prints loan information
        if(verify==0) {
            view.displayRate(mortgage.getRate());
            view.displayApproved(mortgage.loanApproved());
            if (mortgage.loanApproved())
                view.displayPayment(mortgage.getPayment());
            else view.displayPayment(0);
        }
    }

}
