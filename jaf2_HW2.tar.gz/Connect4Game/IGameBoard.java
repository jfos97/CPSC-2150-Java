package Connect4Game;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 2
 */
public interface IGameBoard {

    /**
     * @pre c >= 0 && c <= total columns
     * @param c column of piece to be played
     * @return true if c is not full, false otherwise
     */

    default boolean checkIfFree(int c)
    {
        int i = getNumRows()-1;
        if(whatsAtPos(i,c)==' '){return true;}
        return false;
    }

    /**
     * @pre c >= 0 && c <= total columns
     * @param c column of last placed piece
     * @return true if last played piece resulted in win, false otherwise
     */

    default boolean checkForWin(int c)
    {
        int rowCheck = getNumRows()-1;
        char p = ' ';
        //use while loop to find row of last placed marker in column
        while(p == ' ')
        {
            p = whatsAtPos(rowCheck,c);
            rowCheck--;
        }
        rowCheck+=1;

        //function calls to check for all possible wins
        if(checkDiagWin(rowCheck ,c, p))
        {return true;}
        if(checkHorizWin(rowCheck, c, p))
        {return true; }
        else if(checkVertWin(rowCheck, c ,p))
        {return true;}
        else {return false;}

    }
    /**
     *
     * @param p is marker of last played piece
     * @param c is column of last played marker
     * @Pre checkIfFree(c)== true
     * @Post p will be the placed in the lowest free spot in column c
     *
     */
    void placeToken(char p, int c);

    /**
     *
     * @param r row of last played piece
     * @param c column of last played piece
     * @param p marker of last played piece
     * @return true if last played piece result in win by horizontal, false otherwise
     */
    boolean checkHorizWin(int r, int c, char p);

    /**
     *
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     * @return return true if the last played piece resulted in a vertical win, false otherwise
     */
    boolean checkVertWin(int r, int c, char p);
    /**
     *
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     * @return return true if the last played piece resulted in a diagonal 4 in a row, false otherwise
     */
    boolean checkDiagWin(int r, int c, char p);

    /**
     *
     * @param r row of desired marker
     * @param c column of desired marker
     * @return marker that is at [r][c], returns ' ' if there is no marker
     */

    char whatsAtPos(int r, int c);

    /**
     *
     * @return true if game ended in tie, false otherwise
     * @Pre no previous play has resulted in a win
     * @Post checkTie == true iff [there are no available spaces left on the board]
     *
     */
    boolean checkTie();

    /**
     *
     * @return the number of rows in the GameBoard
     */
    int getNumRows();

    /**
     *
     * @return the number of columns in the GameBoard
     */
    int getNumColumns();

    /**
     *
     * @return the number of tokens in a row needed to win the game
     */
    int getNumToWin();


}
