package Connect4Game;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 3
 */

import java.util.*;


public class GameBoardMem extends AbsGameBoard {
    /**
     * @invariant r >= 0 && r <= 100
     * @invariant c >= 0 && c <= 100
     *
     */

    private Map<Integer, List<Character>> board;
    private int numToWin;
    private int numRows;
    private int numColumns;

    //constructor
    public GameBoardMem(int rows, int col, int win)
    {
        board = new HashMap<>();
        numToWin = win;
        numRows = rows;
        numColumns = col;
    }

    public void placeToken(char p, int c)
    {
        List<Character> row = new ArrayList<>();

        //check if map is empty
        if(board.isEmpty()){board.put(c, row);}

        //check if map contains key
        else if(!board.containsKey(c)){board.put(c, row);}

        //places token
        board.get(c).add(p);
    }

    public char whatsAtPos(int r, int c)
    {
        //checks if map contains key, if not return blank space
        if(!board.containsKey(c)){return ' ';}
        List<Character> row = board.get(c);

        //checks if column has row smaller than size of board, if so return blank space
        if( row.size()<=r){return ' ';}

        //return place at position
        else {return row.get(r);}
    }

    public int getNumRows() {return numRows; }

    public int getNumColumns() {return numColumns; }

    public int getNumToWin() {return numToWin; }
}
