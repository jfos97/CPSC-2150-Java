package cpsc2150.queues;

/**
 * A queue is a First in First out ordered collection
 * initialization ensures: this = <> [Queue is empty] and size = 0
 * Defines: size: Z - number of items in the queue
 * constraints: 0 <= size <= MAX_SIZE
 */

public interface IQueue <T> {
    int MAX_SIZE = 100;

    /**
     * Adds a value to the back of the Queue
     * @param val
     * @pre size < MAX_SIZE
     */
    void add(T val);

    /**
     * Gets the value from the front of the Queue, returns it and removes it from the queue
     * @return The value from the front of the Queue
     * @pre size > 0
     * @post #this = <getNext> o <this>
     *     [i.e. the first value in the queue is returned, and removed from the queue]
     */
    T getNext();

    /**
     * Returns the number of items in the Queue
     * @return the number of items in the queue
     * @post: getSize = size
     */
    int getSize();

    /**
     * reverses the queue (back is now the front)
     * @pre size > 1
     * @post q is = #q reversed
     */
    void reverse();
}
