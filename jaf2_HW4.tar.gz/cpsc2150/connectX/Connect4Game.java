package cpsc2150.connectX;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 4
 */

import java.util.*;

public class Connect4Game {

    public static void main(String [] args)
    {

        IGameBoard board;
        Scanner scanner = new Scanner((System.in));
        String clearBuff;
        int input, verify;
        String nGame = "Y";
        List<Character> players;

        //while loop to play game
        while(nGame.equals("y")||nGame.equals("Y")) {

            //the making of the rules and board

            int row=-1, col=-1, howManyToWin=-1, numOfPlayers=-1;
            int win=0;
            players= new ArrayList<>();

            //get number of players and verify valid input
            while(numOfPlayers<2 || numOfPlayers>10)
            {
                System.out.println("How many players?");
                numOfPlayers = scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(numOfPlayers<2){System.out.println("Must be at least 2 players");}
                else if(numOfPlayers>10) { System.out.println("Must be 10 players of fewer"); }
            }

            //assign each player a token
            for(int i = 1; i<=numOfPlayers; i++)
            {
                String p;
                char c;
                System.out.println("Enter character to represent player "+i);
                p = scanner.nextLine();
                c = Character.toUpperCase(p.charAt(0));
                if(players.isEmpty()){players.add(c);}
                //check if character has already been chosen
                else if(players.contains(c))
                {
                    System.out.println(c+" is already taken as a player token");
                    i--;
                }
                else{players.add(c);}
            }

            //while loop to ask for number of rows and check for valid number
            while(row<3 || row>100) {
                System.out.println("How many rows should be on the board?");
                row=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(row<3) {System.out.println("Must have at least 3 rows");}
                else if(row>100){ System.out.println("Can have at most 100 rows");}
            }

            //while loop to ask for number of rows and check for valid number
            while(col<3 || col>100) {
                System.out.println("How many columns should be on the board?");
                col=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(col<3) {System.out.println("Must have at least 3 columns");}
                else if (col>100){System.out.println("Can have at most 100 columns");}
            }

            //while loop to ask for number of rows and check for valid number
            while(howManyToWin<3||howManyToWin>25) {
                System.out.println("How many in a row to win?");
                howManyToWin=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(howManyToWin<3){ System.out.println("Must have at least 3 in a row to win");}
                else if(howManyToWin>25){System.out.println("Can have at most 25 in a row to win");}
                else if(howManyToWin>col&&howManyToWin>row)
                {
                    System.out.println("Not possible to win with size of board");
                    howManyToWin = -1;
                }
            }

            //user chooses type of games board, fast or memory based
            char gameType = '\0';
            verify =0;
            while(verify==0)
            {
                String pickOne;
                System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m)?");
                pickOne = scanner.nextLine();
                gameType = Character.toUpperCase(pickOne.charAt(0));

                if(gameType== 'F'|| gameType=='M'){verify = 1; }
                else {System.out.println("Please enter F or M"); }
            }

            //construct game board
            if(gameType == 'F') {board = new GameBoard(row, col, howManyToWin);}
            else {board = new GameBoardMem(row, col, howManyToWin);}
            System.out.println(board.toString());
            int piecesToUse = row * col;

            //play game

            //loops through players till either a win appears or there are no more pieces to be played
            int  i=0;
            while (piecesToUse > 0) {

                System.out.println("Player " + players.get(i) + " what column do you want to place your marker in?");
                input = scanner.nextInt();
                clearBuff = scanner.nextLine();

                verify = 0;
                //verify user input
                while (verify == 0) {
                    //check if desired column is within bound of game board
                    if (input < 0 || input >= col) {
                        System.out.println("Column must be between 0 and " + (col - 1));
                        System.out.println("Player " + players.get(i) + " what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                        continue;
                    }
                    //confirm column desired is not full
                    if (!board.checkIfFree(input)) {
                        System.out.println("Column is full");
                        System.out.println("Player " + players.get(i) + " what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                    }
                    else {verify =1;}
                }

                //place token and print game board
                board.placeToken(players.get(i), input);
                System.out.println(board.toString());


                //checks for win
                if (board.checkForWin(input)) {
                    System.out.println("Player " + players.get(i)+" Won!");
                    piecesToUse =0;

                    win = 1;
                    verify = 0;
                    //if won, asks to play again
                    while (verify != 1) {
                        System.out.println("Would you like to play again?  Y/N");
                        nGame = scanner.nextLine();
                        if (nGame.equals("y") || nGame.equals("Y")) {
                            verify = 1;
                        }
                        else if (nGame.equals("n") || nGame.equals("N"))
                        { verify = 1; }
                    }
                }

                piecesToUse--;
                //change player
                if(i<numOfPlayers-1){i++;}
                else{i=0;}
            }

            //after all pieces are played, check for tie and asks to play again
            if (board.checkTie() && win!=1) {
                System.out.println("Tie game");
                verify = 0;
                while (verify != 1) {
                    System.out.println("Would you like to play again?  Y/N");
                    nGame = scanner.nextLine();
                    if (nGame.equals("y") || nGame.equals("Y")) {
                        verify = 1;
                    }
                    else if (nGame.equals("n") || nGame.equals("N"))
                    {verify = 1;}
                }
            }
        }
        System.exit(0);
    }
}
