package cpsc2150.queues;
//James Foster

/**
 * An implementation og IQueue using an array
 *
 * correspondences: size = top +1
 *                  this = q[0] to q[top]
 *                  q[0] is the front of the queue
 *
 * invariant: -1 <= top < MAX_SIZE
 */

public class MyQueue<T> extends AbsQueue<T> implements IQueue<T> {
    private T[] q;
    private int top;


    MyQueue(){
        q = (T[]) new Object[MAX_SIZE];
        top = -1;
    }

    public void add(T val){
        top++;
        q[top] = val;
    }

    public T getNext(){
        T ret = q[0];
        //shift everything over
        for(int i=1; i<=top; i++)
        {
            q[i-1] = q[i];
        }
        top--;
        return ret;
    }

    public int getSize()
    {
        return top +1;
    }

    public void reverse()
    {
        T[] q2 = (T[]) new Object[MAX_SIZE];

        //for loop starts at back of queue and adds all values to q2
        int j = 0;
        for(int i = getSize() - 1; i>=0; i--) {
            q2[j] = q[i];
            j++;
        }
        //loop adds values from q2(which is the reverse of q)
        //and removes all values from begging of queue
        for(int i = 0; i<getSize(); i++) {
            add(q2[i]);
            getNext();
        }

    }



}
