package Lab5;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestArraySet {

    //Method to construct set
    private ISet<Integer> MakeASet()
    {
        ISet<Integer> arr = new ArraySet<Integer>();
        return arr;
    }

    @Test
    public void testAdd400()
    {
        ISet<Integer> arr = MakeASet();

        //add to set
        arr.add(400);

        //correct size
        int size = 1;
        int checkSize = arr.getSize();
        assertTrue(arr.contains(400));
        assertTrue(size == checkSize);
    }
    @Test
    public void testAdd0_100()
    {
        ISet<Integer> arr = MakeASet();

        //add to set
        arr.add(0);
        arr.add(100);

        //correct size
        int size = 2;
        int checkSize = arr.getSize();
        assertTrue(arr.contains(0));
        assertTrue(size== checkSize);

    }
    @Test
    public void testAdd30000_200_1_30()
    {
        ISet<Integer> arr = MakeASet();

        //add to set
        arr.add(30000);
        arr.add(200);
        arr.add(1);
        arr.add(30);
        //checks if correct size
        int wrongSize = 1;
        int checkSize = arr.getSize();
        assertTrue(arr.contains(30000));
        assertTrue(wrongSize!=checkSize);

    }

    @Test
    public void testContains400()
    {
        ISet<Integer> arr = MakeASet();

        //add to set
        arr.add(400);
        assertTrue(arr.contains(400));
    }
    @Test
    public void testContains_checkWrongNum()
    {
        ISet<Integer> arr = MakeASet();
        //add to set
        arr.add(1);
        int wrongNum = 400;
        assertTrue(!arr.contains(wrongNum));
    }
    @Test
    public void testContains9000_inBigSet()
    {
        ISet<Integer> arr = MakeASet();

        //add to set
        arr.add(12);
        arr.add(9000);
        arr.add(30);
        arr.add(20000);
        assertTrue(arr.contains(9000));
    }
    @Test
    public void testEquals_NotEqual()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();

        //set1
        arr.add(40000);
        arr.add(0);
        //set2
        arr2.add(78);
        arr2.add(40000);

        assertTrue(!arr.equals(arr2));
    }
    @Test
    public void testEquals2_equalTo()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();

        //set1
        arr.add(12);
        arr.add(9000);
        arr.add(30);
        arr.add(20000);

        //set2
        arr2.add(12);
        arr2.add(9000);
        arr2.add(30);
        arr2.add(20000);

        assertTrue(arr.equals(arr2));
    }
    @Test
    public void testEquals_EmptySets()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();

        assertTrue(arr.equals(arr2));
    }

    @Test
    public void testIntersect_2Intersects()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set1
        arr.add(12);
        arr.add(9000);
        arr.add(30);
        arr.add(20000);

        //set2
        arr2.add(30);
        arr2.add(20000);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(30);
        testArr.add(20000);

        arr.intersect(arr2);
        assertTrue(arr.equals(testArr));
    }
    @Test
    public void testIntersect2_noIntersects()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(12);
        arr.add(9000);
        arr.add(30);
        arr.add(20000);

        //set 2
        arr2.add(4154);
        arr2.add(0);
        arr2.add(484);
        arr2.add(2);


        arr.intersect(arr2);
        assertTrue(arr.equals(testArr));
    }

    @Test
    public void testIntersect3()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(24);
        arr.add(90);
        arr.add(3572);
        arr.add(23146);

        //set2
        arr2.add(30);
        arr2.add(20000);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(30);
        testArr.add(20000);

        arr.intersect(arr2);
        assertTrue(!arr.equals(testArr));
    }

    @Test
    public void testUnion1()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set1
        arr.add(12);
        arr.add(9000);
        arr.add(30);
        arr.add(20000);

        //set2
        arr2.add(30);
        arr2.add(20000);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(30);
        testArr.add(20000);
        testArr.add(12);
        testArr.add(9000);
        testArr.add(484);
        testArr.add(2);

        arr.union(arr2);
        assertTrue(arr.equals(testArr));
    }
    @Test
    public void testUnion_testSetNotEqual()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set1
        arr.add(12);
        arr.add(20000);

        //set2
        arr2.add(30);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(30);


        arr.union(arr2);
        assertTrue(!arr.equals(testArr));
    }
    @Test
    public void testUnion_UnionIsAllValues()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(12);
        arr.add(9000);

        //set 2
        arr2.add(82450);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(12);
        testArr.add(9000);
        testArr.add(82450);
        testArr.add(484);
        testArr.add(2);

        arr.union(arr2);
        assertTrue(arr.equals(testArr));
    }
    @Test
    public void testDifference1_NoDifference()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(12);
        arr.add(9000);

        //set 2
        arr2.add(12);
        arr2.add(9000);

        arr.difference(arr2);
        assertTrue(arr.equals(testArr));
    }
    @Test
    public void testDifference2_notEqual()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(12);
        arr.add(9000);

        //set 2
        arr2.add(82450);
        arr2.add(484);
        arr2.add(2);

        //test set
        testArr.add(17765);
        testArr.add(900);
        testArr.add(8);
        testArr.add(41);
        testArr.add(2);

        arr.difference(arr2);
        assertTrue(!arr.equals(testArr));
    }
    @Test
    public void testDifference3_2diffValue()
    {
        ISet<Integer> arr = MakeASet();
        ISet<Integer> arr2 = MakeASet();
        ISet<Integer> testArr = MakeASet();

        //set 1
        arr.add(12);
        arr.add(9000);
        arr.add(82450);

        //set 2
        arr2.add(12);
        arr2.add(4000);
        arr2.add(153);

        //test set
        testArr.add(9000);
        testArr.add(82450);


        arr.difference(arr2);
        assertTrue(arr.equals(testArr));
    }

}


