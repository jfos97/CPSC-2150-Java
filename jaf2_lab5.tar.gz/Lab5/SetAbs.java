package Lab5;
import java.lang.*;

public abstract class SetAbs<T> implements ISet<T> {


    public abstract void add(T val);

    public abstract T removePos(int pos);

    public abstract boolean contains(T val);

    public abstract int getSize();

    /**
     *
     * @return string of values in set
     */
    @Override
    public String toString()
    {
        //add each value in array to string
        T pos;
        int i;
        String j = "";
        for (i=0; i<this.getSize(); i++)
        {

            pos = this.removePos(0);
            j=j + pos+", ";
            this.add(pos);
        }
        return j;
    }

    /**
     *
     * @param set2 is the set passed in to compare is they are equal
     * @return true if sets are equal, false otherwise
     */
    public boolean equals(Object set2)
    {
        if(set2 instanceof ISet) {
            ISet<T> temp = (ISet<T>) set2;
            if (this.getSize() != temp.getSize()) {
                return false;
            }

            for (int i = this.getSize()-1; i >= 0; i--) {
                if (!this.contains(temp.removePos(i))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

}
