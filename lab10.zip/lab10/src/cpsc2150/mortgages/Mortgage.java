package cpsc2150.mortgages;

public class Mortgage extends AbsMortgage implements IMortgage {


    private int years;
    private double downPayment;
    private double totalCost;
    private double principle;
    private double monthlyPayments;
    private double APR = BASERATE;
    private ICustomer customer;

    /**
     *
     * @param cost of mortgage
     * @param downPayment
     * @param years of loan
     * @param customer info of customer
     */
    Mortgage(double cost, double downPayment, int years, ICustomer customer)
    {
        int credit = customer.getCreditScore();

        this.totalCost = cost;
        this.downPayment = downPayment;
        this.principle = cost-downPayment;
        this.years = years;
        this.customer = customer;

        //calculate APR

        //years add to APR
        if(years<MAX_YEARS){APR+=GOODRATEADD;}
        else{APR += NORMALRATEADD;}

        //down payment add to APR
        if(downPayment<(cost*PREFERRED_PERCENT_DOWN)){APR+=GOODRATEADD;}

        //credit score adds to APR
        if(credit<BADCREDIT){APR+=VERYBADRATEADD;}
        else if(credit>BADCREDIT && credit<FAIRCREDIT){APR+=BADRATEADD;}
        else if(credit>FAIRCREDIT && credit<GOODCREDIT){APR+=NORMALRATEADD;}
        else if(credit>=GOODCREDIT && credit<GREATCREDIT){APR+=GOODRATEADD;}

        //calculate monthly payments
        double monthlyRate= APR/12;
        int numberOfPayments = years*12;
        monthlyPayments = (monthlyRate*principle)/(1-Math.pow((1+monthlyRate), (-numberOfPayments)));

    }
    public boolean loanApproved(){
        if(years<MIN_YEARS)
        {return false;}
        //APR
        if(APR>=RATETOOHIGH){return false;}
        //percent down
        if(downPayment/totalCost<MIN_PERCENT_DOWN)
        {return false;}
        //debt to income ratio
        if((((customer.getMonthlyDebtPayments()+monthlyPayments)*12)/customer.getIncome())>DTOITOOHIGH)
        {return false;}
        else {
            return true;
        }
    }

    public double getPayment(){return monthlyPayments; }

    public double getRate() {return APR;}

    public double getPrincipal(){return principle; }

    public int getYears(){return years;}


}
