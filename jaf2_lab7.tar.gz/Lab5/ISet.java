package Lab5;
/*
    James Foster
    CPSC 2150
    lab 5
 */

public interface ISet <T>{

    /**
     * @param val is number to be added to set
     * @pre val cannot already be in set
     * @Post value has been added to back of set
     */
    void add(T val);

    /**
     *
     * @param pos is what position in set to be removed
     * @return returns value of what the position removed held
     * @pre pos must be within size of set && set cannot be empty
     * @Post pos has been removed and set size is size-1
     *
     */
    T removePos(int pos);

    /**
     *
     * @param val is what will be used to compare and find if that value is in set
     * @return true if set already contain val, false otherwise
     * @Pre val must be an int
     *
     */
    boolean contains(T val);

    /**
     *
     * @return the size of the set.
     * @Pre array set must be created
     *
     */
    int getSize();

    /**
     *
     * @param unionWith is the 2nd set that is being used to unionize
     * @Pre both sets must be initialized
     * @Post No duplicates in unionized set
     *
     */
    default void union(ISet<T> unionWith)
    {
        T num;
        int j=0;

        for(int i=unionWith.getSize()-1; i>=0; i--)
        {
            num = unionWith.removePos(j);
            if(!this.contains(num)) {this.add(num);}
        }
    }

    /**
     *
     * @param intWith is 2nd set that is being used to for finding intersecting values
     * @Pre both sets must be initialized
     * @Post ending result must be a set of only the values the 2 sets had in common
     */
    default void intersect(ISet<T> intWith)
    {
        T num;
        int j;
            for (j = this.getSize() - 1; j >= 0; j--)
            {
                num = this.removePos(j);
                if (intWith.contains(num)) {this.add(num);}
            }
    }


    /**
     *
     * @param diffWith is 2nd set that is being used for finding the difference od 2 sets
     * @Pre both sets must be initialized
     * @Post result must only contain the values of set one that were not also in set 2
     */
    default void difference(ISet<T> diffWith)
    {
        T num;
        int size;
        size = this.getSize()-1;

        for (int i=size; i>=0; i--)
        {
            num = this.removePos(i);

            if (!diffWith.contains(num)) { this.add(num); }
        }
    }

}
