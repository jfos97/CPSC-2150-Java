package cpsc2150.connectX;

/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 4
 */

public class GameBoard extends AbsGameBoard implements IGameBoard{
    /**
     * @invariant r >= 0 && r <= 5
     * @invariant c >= 0 && c <= 6
     * @invariant p must be 'X', 'O' or ' '
     */

    private char [][] board;
    private int numToWin;

    //Constructor for game board
    public GameBoard(int row, int column, int win)
    {
        int i, j;
        this.numToWin = win;
        board = new char [row][column];
        for(i=0; i<board.length; i++)
        {
            for(j=0; j<board[i].length; j++)
            {
                board[i][j] = ' ';
            }
        }
    }

    public void placeToken(char p, int c)
    {
        int i, row=0;
        //for loop to find lowest row in column to place marker
        for(i=board.length-1; i>=0; i--)
        {
            if(board[i][c]==' ') {
                row = i;
            }
        }
        board[row][c]= p;
    }

    public char whatsAtPos(int r, int c) { return board[r][c]; }

    public int getNumRows() {return board.length; }

    public int getNumColumns() {return board[0].length; }

    public int getNumToWin() {return numToWin; }
}
