/*
    James Foster
    CPSC 2150
    lab 3
 */
public interface ISet
{

    /**
     *
     * @param val is number to be added to set
     * @pre val cannot already be in set
     *
     */
    void add(int val);

    /**
     *
     * @param pos is what position in set to be removed
     * @return returns value of what the position removed held
     * @pre pos must be within size of set && set cannot be empty
     *
     */
    int removePos(int pos);

    /**
     *
     * @param val is what will be used to compare and find if that value is in set
     * @return true if set already contain val, false otherwise
     */
    boolean contains(int val);

    /**
     *
     * @return the size of the set.
     * @pre array set must be created
     */
    int getSize();

}
