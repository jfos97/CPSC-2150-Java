/*
    James Foster
    CPSC 2150
    lab 3
 */
//import java.util.*;
import java.lang.*;

public class ArraySet
{
    private int[] array;
    private int size=0;


    /**
     *
     * @return string of values in set
     */
    @Override
    public String toString()
    {
        int i;
        String j = "";
        for (i=0; i<size; i++) { j = j + array[i]+", ";}
        return j;
    }

    ArraySet()
    {
        array = new int [100];

    }

    void add(Integer val)
    {
        array[size] = val;
        size++;
    }

    Integer removePos(int pos)
    {
        int num, i;

        num = array[pos];

        for(i=pos;i<size; i++)
        {
            array[i] = array[i+1];
        }
        size--;

        return num;

    }

    boolean contains(Integer val)
    {
        int i;

        for(i=0; i<size; i++)
        {
            if(array[i]==val)
            {return true;}

        }
        return false;
    }

    int getSize()
    {
        return size;
    }

}
