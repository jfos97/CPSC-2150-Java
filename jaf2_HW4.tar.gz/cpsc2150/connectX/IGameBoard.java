package cpsc2150.connectX;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 4
 */
public interface IGameBoard {

    /**
     * @pre c >= 0 && c <= total columns
     * @post true if c is not full, false otherwise
     * @param c column of piece to be played
     * @return true or false
     */

    default boolean checkIfFree(int c)
    {
        int i = getNumRows()-1;
        if(whatsAtPos(i,c)==' '){return true;}
        return false;
    }

    /**
     * @pre c >= 0 && c <= total columns
     * @post true if last played piece resulted in win, false otherwise
     * @param c column of last placed piece
     * @return true or false
     */

    default boolean checkForWin(int c)
    {
        int rowCheck = getNumRows()-1;
        char p = ' ';

        //use while loop to find row of last placed marker in column
        while(p == ' ')
        {
            p = whatsAtPos(rowCheck,c);
            rowCheck--;
        }
        rowCheck+=1;

        //function calls to check for all possible wins
        if(checkDiagWin(rowCheck ,c, p))
        {return true;}
        if(checkHorizWin(rowCheck, c, p))
        {return true; }
        else if(checkVertWin(rowCheck, c ,p))
        {return true;}
        else {return false;}

    }
    /**
     *
     * @param p is marker of last played piece
     * @param c is column of last played marker
     * @Pre checkIfFree(c)== true
     * @Post p will be the placed in the lowest free spot in column c
     *
     */
    void placeToken(char p, int c);

    /**
     * @pre r and c must be within bounds of game boards size
     * @post true if last played piece result in win by horizontal, false otherwise
     * @param r row of last played piece
     * @param c column of last played piece
     * @param p marker of last played piece
     * @return true or false
     */
    default boolean checkHorizWin(int r, int c, char p)
    {
        int n =0, col;

        for (col=0; col < getNumColumns()-1; col++)
        {
            if(whatsAtPos(r, col) ==p)
            {
                n+=1;
            }
            else{n=0;}
            if(n==getNumToWin()){return true;}
        }
        return false;
    }

    /**
     *
     * @pre r and c must be within bounds of game boards size
     * @post true if last played piece result in win by vertical, false otherwise
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     * @return true or false
     */
    default boolean checkVertWin(int r, int c, char p)
    {
        int n = 0, row ;

        for (row = r; row >= 0; row--) {
            if (whatsAtPos(row, c)==p) {
                n += 1;
            }
            else {n = 0;}
            if (n == getNumToWin()) { return true; }
        }
        return false;
    }
    /**
     * @pre r and c must be within bounds of game boards size
     * @post true if the last played piece resulted in a diagonal 4 in a row, false otherwise
     * @param r is row of last placed marker
     * @param c is column of last placed marker
     * @param p is what marker was last placed, X or O
     * @return true or false
     */
    default boolean checkDiagWin(int r, int c, char p)
    {

        int rowCheck, colCheck, n;
        //variable n is counter for how many in a row


        //nested for loop checks for bottom left to top right diagonal win
        for (int row = 0; row <= getNumRows() - getNumToWin(); row++) {
            for (int col = 0; col <=getNumColumns() - getNumToWin(); col++) {
                if (whatsAtPos(row,col)!=' ' && whatsAtPos(row, col) == whatsAtPos(row + 1, col + 1)) {
                    n = 2;
                    rowCheck = row + 1;
                    colCheck = col + 1;

                    while (n > 0) {
                        if (whatsAtPos(rowCheck, colCheck) == whatsAtPos(rowCheck + 1, colCheck + 1)) {
                            n += 1;
                        } else {
                            n = 0;
                        }
                        if (n == getNumToWin()) {
                            return true;
                        }
                        rowCheck += 1;
                        colCheck += 1;
                    }
                }
            }
        }
        //nested for loop checks for top left to bottom right diagonal win
        for (int row = getNumRows() - 1; row >=getNumToWin()-1; row--) {
            for (int col = 0; col <= getNumColumns() - getNumToWin(); col++) {
                if (whatsAtPos(row,col)!=' ' && whatsAtPos(row, col) == whatsAtPos(row - 1, col +1)) {
                    n = 2;
                    rowCheck = row - 1;
                    colCheck = col + 1;

                    while (n > 0) {
                        if (whatsAtPos(rowCheck, colCheck) == whatsAtPos(rowCheck - 1, colCheck + 1)) {
                            n += 1;
                        } else {
                            n = 0;
                        }
                        if (n == getNumToWin()) {
                            return true;
                        }
                        rowCheck -= 1;
                        colCheck += 1;
                    }
                }
            }

        }
        return false;

    }

    /**
     * @pre r and c must be within bound or rows and columns
     * @post marker that is at posistion [r][c] if retruned, returns ' ' if there is no marker
     * @param r row of desired marker
     * @param c column of desired marker
     * @return marker at pos
     */

    char whatsAtPos(int r, int c);

    /**
     * @pre game board must be full
     * @post returns true if no previous play resulted in a win, flase otherwise
     * @return true if game ended in tie, false otherwise
     * @Pre no previous play has resulted in a win
     * @Post true or false
     *
     */
    default boolean checkTie()
    {

        //checks for any free spaces at top of board.
        for(int i=0; i<getNumColumns();i++)
        {
            if (checkIfFree(i))
            {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @return the number of rows in the GameBoard
     */
    int getNumRows();

    /**
     *
     * @return the number of columns in the GameBoard
     */
    int getNumColumns();

    /**
     *
     * @return the number of tokens in a row needed to win the game
     */
    int getNumToWin();


}
