package cpsc2150.connectX;

/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 4
 */

import org.junit.Test;
import static org.junit.Assert.*;

public class TestGameBoard {

    private final int rowTest1 = 10, rowTest2 = 15, rowTest3 = 100, rowTest4 = 3;
    private final int colTest1 = 10, colTest2 = 15, colTest3 = 100, colTest4 = 3;
    private final int toWin1 = 3, toWin2 = 5, toWin3 = 25;
    private final char P1 = 'X', P2 = 'O', P3 = 'F';


    private IGameBoard board;
    private char [][] expectedArr;

    //Method to construct board
    private IGameBoard makeBoard(int row,int col,int win)
    {
        IGameBoard board = new GameBoard(row, col, win);
        return board;
    }

    private String makeExpected(char[][] arrBoard)
    {
        String expected = "";

        //column numbers
        for(int i =0; i < arrBoard[0].length; i++ )
        {
            if(i<10) { expected += "| "+i; }
            else { expected += "|"+i; }
        }
        //insert newline after column numbers
        expected+="|\n";

        //make string to check if what should be matches correct output.
        for (int row =0 ; row <=arrBoard.length-1; row++)
        {
            expected += "|";
            for (int col = 0; col < arrBoard[row].length; col++) {
                if (arrBoard[row][col] == '\0') {
                    expected += "  |";
                } else {
                    expected += arrBoard[row][col] + " |";
                }
            }
            expected += "\n";
        }

        return expected;
    }


    //same values for row & col
    @Test
    public void constructor1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        assertEquals(rowTest1, board.getNumRows());
        assertEquals(colTest1, board.getNumColumns());
        assertEquals(toWin1, board.getNumToWin());
    }
    //different values for rows and columns
    @Test
    public void constructor2()
    {
        board = makeBoard(rowTest1, colTest2, toWin1);
        assertEquals(rowTest1, board.getNumRows());
        assertEquals(colTest2, board.getNumColumns());
        assertEquals(toWin1, board.getNumToWin());
    }
    //big numbers for all parameters
    @Test
    public void constructor3()
    {
        board = makeBoard(rowTest3, colTest3, toWin3);
        assertEquals(rowTest3, board.getNumRows());
        assertEquals(colTest3, board.getNumColumns());
        assertEquals(toWin3, board.getNumToWin());
    }

    //first token placed
    @Test
    public void placetoken1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        expectedArr = new char [rowTest1][colTest1];
        String correct;

        board.placeToken(P1, 3);
        expectedArr[9][3] = P1;

        correct = makeExpected(expectedArr);

        assertEquals(correct, board.toString());
    }

    //not empty row
    @Test
    public void placetoken2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        expectedArr = new char [rowTest1][colTest1];
        String correct;

        board.placeToken(P1, 1);
        board.placeToken(P2, 2);
        board.placeToken(P1, 3);
        board.placeToken(P2, 1);
        expectedArr[9][1] = P1;
        expectedArr[9][2] = P2;
        expectedArr[9][3] = P1;
        expectedArr[8][1] = P2;

        correct = makeExpected(expectedArr);

        assertEquals(correct, board.toString());
    }

    //place token in top row
    @Test
    public void placetoken3()
    {

        board = makeBoard(rowTest1, colTest1, toWin1);
        expectedArr = new char [rowTest1][colTest1];
        String correct;

        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        expectedArr[9][1] = P1;
        expectedArr[8][1] = P2;
        expectedArr[7][1] = P1;
        expectedArr[6][1] = P2;
        expectedArr[5][1] = P1;
        expectedArr[4][1] = P2;
        expectedArr[3][1] = P1;
        expectedArr[2][1] = P2;
        expectedArr[1][1] = P1;
        expectedArr[0][1] = P2;

        correct = makeExpected(expectedArr);
        assertEquals(correct, board.toString());
    }

    //place token in column thats not empty but not close to full
    @Test
    public void placetoken4()
    {
        board = makeBoard(rowTest2, colTest2, toWin1);
        expectedArr = new char [rowTest2][colTest2];
        String correct;

        board.placeToken(P1, 3);
        board.placeToken(P2, 1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 2);

        expectedArr[14][3] = P1;
        expectedArr[14][1] = P2;
        expectedArr[14][2] = P1;
        expectedArr[13][2] = P2;

        correct = makeExpected(expectedArr);
        assertEquals(correct, board.toString());
    }

    //place tokens in first and last columns
    @Test
    public void placetoken5()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        expectedArr = new char [rowTest1][colTest1];
        String correct;

        board.placeToken(P1, 0);
        board.placeToken(P2, 0);
        board.placeToken(P1, 9);
        board.placeToken(P2, 9);

        expectedArr[9][0] = P1;
        expectedArr[8][0] = P2;
        expectedArr[9][9] = P1;
        expectedArr[8][9] = P2;

        correct = makeExpected(expectedArr);
        assertEquals(correct, board.toString());
    }

    //empty board
    @Test
    public void whatAtPos1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        assertEquals(' ', board.whatsAtPos(0,0));
    }

    //slot at bottom
    @Test
    public void whatAtPos2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);

        board.placeToken(P1, 9);
        board.placeToken(P2, 9);
        assertEquals(P1, board.whatsAtPos(0,9));

    }
    //slot at top of col
    @Test
    public void whatAtPos3()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        assertEquals(P2, board.whatsAtPos(9,1));
    }
    //middle of column
    @Test
    public void whatAtPos4()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        assertEquals(P2, board.whatsAtPos(5,1));


    }
    //big board, 2nd piece in high row
    @Test
    public void whatAtPos5()
    {
        board = makeBoard(rowTest3, colTest3, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 80);
        board.placeToken(P1, 15);
        board.placeToken(P2, 36);
        board.placeToken(P1, 36);
        board.placeToken(P2, 90);
        board.placeToken(P1, 24);
        board.placeToken(P2, 4);
        assertEquals(P1, board.whatsAtPos(1,36));
    }
    //first column
    @Test
    public void whatAtPos6()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 0);
        board.placeToken(P2, 0);
        assertEquals(P2, board.whatsAtPos(1, 0));
    }
    //last column
    @Test
    public void whatAtPos7()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 9);
        board.placeToken(P2, 9);
        assertEquals(P1, board.whatsAtPos(0, 9));
    }

    //empty row
    @Test
    public void checkIfFree1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        assertTrue(board.checkIfFree(3));
    }

    //not full row
    @Test
    public void checkIfFree2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 3);
        board.placeToken(P2, 3);
        assertTrue(board.checkIfFree(3));
    }
    //full row
    @Test
    public void checkIfFree3()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        assertFalse(board.checkIfFree(1));
    }

    //horz win in bottom row
    @Test
    public void CheckHoriz1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 8);
        board.placeToken(P1, 3);
        assertTrue(board.checkHorizWin(0, 3, P1));
    }
    //horz win middle of board
    @Test
    public void CheckHoriz2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 3);
        board.placeToken(P2, 4);
        board.placeToken(P1, 5);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        board.placeToken(P1, 4);
        board.placeToken(P2, 3);
        board.placeToken(P1, 3);
        board.placeToken(P2, 3);
        board.placeToken(P1, 4);
        board.placeToken(P2, 4);
        board.placeToken(P1, 5);
        assertTrue(board.checkHorizWin(2, 5, P1));
    }
    //no horz win
    @Test
    public void CheckHoriz3()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 3);
        board.placeToken(P2, 4);
        board.placeToken(P1, 5);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        assertFalse(board.checkHorizWin(1, 5, P2));
    }
    //no win when place piece in middle of two opposite pieces
    @Test
    public void CheckHoriz4()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 5);
        board.placeToken(P1, 2);
        board.placeToken(P2, 7);
        board.placeToken(P1, 6);
        assertFalse(board.checkHorizWin(0, 6, P1));
    }
    //win when placed in middle of two peice
    @Test
    public void CheckHoriz5()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 5);
        board.placeToken(P1, 4);
        board.placeToken(P2, 5);
        board.placeToken(P1, 3);
        assertTrue(board.checkHorizWin(0, 3, P1));
    }
    //vert win from bottom
    @Test
    public void checkVert1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 5);
        board.placeToken(P1, 2);
        board.placeToken(P2, 0);
        board.placeToken(P1, 2);
        assertTrue(board.checkVertWin(2, 2, P1));
    }

    //vert win in last column
    @Test
    public void checkVert2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 9);
        board.placeToken(P2, 5);
        board.placeToken(P1, 9);
        board.placeToken(P2, 0);
        board.placeToken(P1, 9);
        assertTrue(board.checkVertWin(2, 9, P1));
    }
    //vert win in middle of board
    @Test
    public void checkVert3()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 5);
        board.placeToken(P2, 5);
        board.placeToken(P1, 5);
        board.placeToken(P2, 5);
        board.placeToken(P1, 2);
        board.placeToken(P2, 5);
        board.placeToken(P1, 9);
        board.placeToken(P2, 5);
        assertTrue(board.checkVertWin(5, 5, P2));
    }
    //last piece in column win
    @Test
    public void checkVert4()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 4);
        board.placeToken(P2, 1);
        board.placeToken(P1, 3);
        board.placeToken(P2, 1);
        assertTrue(board.checkVertWin(9, 1, P2));

    }
    //no vert win when need 5 in row and have 4
    @Test
    public void checkVert5()
    {
        board = makeBoard(rowTest2, colTest2, toWin2);
        board.placeToken(P1, 1);
        board.placeToken(P2, 2);
        board.placeToken(P1, 1);
        board.placeToken(P2, 3);
        board.placeToken(P1, 1);
        board.placeToken(P2, 10);
        board.placeToken(P1, 1);
        assertFalse(board.checkVertWin(3, 1, P1));
    }

    //win last piece places if top left, and makes to bottom right
    @Test
    public void checkDiag1()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 3);
        board.placeToken(P2, 2);
        board.placeToken(P1, 2);
        board.placeToken(P2, 9);
        board.placeToken(P1, 1);
        assertTrue(board.checkDiagWin(2, 1, P1));
    }
    //last piece placed makes win bottom right to top left
    @Test
    public void checkDiag2()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 2);
        board.placeToken(P1, 2);
        board.placeToken(P2, 9);
        board.placeToken(P1, 3);
        assertTrue(board.checkDiagWin(0, 3, P1));
    }
    //win in middle of board
    @Test
    public void checkDiag3()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 4);
        board.placeToken(P2, 4);
        board.placeToken(P1, 4);
        board.placeToken(P2, 5);
        board.placeToken(P1, 5);
        board.placeToken(P2, 5);
        board.placeToken(P1, 6);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 4);
        board.placeToken(P1, 5);
        board.placeToken(P2, 5);
        board.placeToken(P1, 6);
        board.placeToken(P2, 6);
        board.placeToken(P1, 0);
        board.placeToken(P2, 6);
        assertTrue(board.checkDiagWin(5, 6, P2));
    }
    //win with last piece places in last column
    @Test
    public void checkDiag4()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 9);
        board.placeToken(P2, 9);
        board.placeToken(P1, 7);
        board.placeToken(P2, 8);
        board.placeToken(P1, 8);
        board.placeToken(P2, 7);
        board.placeToken(P1, 9);
        assertTrue(board.checkDiagWin(2, 9, P1));
    }
    //no win when need to win is 5 and have 4
    @Test
    public void checkDiag5()
    {
        board = makeBoard(rowTest1, colTest1, toWin2);
        board.placeToken(P1, 4);
        board.placeToken(P2, 4);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        board.placeToken(P1, 5);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 7);
        board.placeToken(P1, 7);
        board.placeToken(P2, 7);
        board.placeToken(P1, 7);
        assertFalse(board.checkDiagWin(3, 7, P1));
    }
    //win when last piece was bottom left makes diag to top right
    @Test
    public void checkDiag6()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        board.placeToken(P1, 5);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 0);
        board.placeToken(P1, 4);
        assertTrue(board.checkDiagWin(0, 4, P1));
    }
    //win when last piece placed in middle of diag win
    @Test
    public void checkDiag7()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        board.placeToken(P1, 4);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 0);
        board.placeToken(P1, 5);
        assertTrue(board.checkDiagWin(1, 5, P1));
    }
    //no win when player 2 blocks player 1 diag win by placing in middle of diag
    @Test
    public void checkDiag8()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 3);
        board.placeToken(P1, 4);
        board.placeToken(P2, 5);
        board.placeToken(P1, 6);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        assertFalse(board.checkDiagWin(2, 5, P2));
    }

    //tie game on board size 3x3
    @Test
    public void checkTie1()
    {
        board = makeBoard(rowTest4, colTest4 , toWin1);
        board.placeToken(P1, 0);
        board.placeToken(P2, 1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 1);
        board.placeToken(P1, 2);
        board.placeToken(P2, 0);
        board.placeToken(P1, 0);
        board.placeToken(P2, 2);
        board.placeToken(P1, 1);
        assertTrue(board.checkTie());

    }
    //no tie cause board is empty
    @Test
    public void checkTie2()
    {
        board = makeBoard(5, 5 , toWin2);
        assertFalse(board.checkTie());
    }
    //tie game with 3 players on 5x5
    @Test
    public void checkTie3()
    {

        board = makeBoard(5, 5 , toWin2);
        board.placeToken(P1, 0);
        board.placeToken(P2, 0);
        board.placeToken(P3, 0);
        board.placeToken(P1, 0);
        board.placeToken(P2, 0);
        board.placeToken(P3, 0);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P3, 1);
        board.placeToken(P1, 1);
        board.placeToken(P2, 1);
        board.placeToken(P3, 2);
        board.placeToken(P1, 2);
        board.placeToken(P2, 2);
        board.placeToken(P3, 2);
        board.placeToken(P1, 2);
        board.placeToken(P2, 3);
        board.placeToken(P3, 3);
        board.placeToken(P1, 3);
        board.placeToken(P2, 3);
        board.placeToken(P2, 3);
        board.placeToken(P3, 4);
        board.placeToken(P1, 4);
        board.placeToken(P2, 4);
        board.placeToken(P3, 4);
        board.placeToken(P1, 4);
        assertTrue(board.checkTie());
    }
    //tie game false cause theres a win
    @Test
    public void checkTie4()
    {
        board = makeBoard(rowTest1, colTest1, toWin1);
        board.placeToken(P1, 6);
        board.placeToken(P2, 5);
        board.placeToken(P1, 5);
        board.placeToken(P2, 6);
        board.placeToken(P1, 6);
        board.placeToken(P2, 0);
        board.placeToken(P1, 4);
        assertFalse(board.checkTie());
    }

}
