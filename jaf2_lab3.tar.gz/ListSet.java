/*
    James Foster
    CPSC 2150
    lab 3
 */
import java.util.*;
import java.lang.*;

public class ListSet
{
    private List<Integer> lSet;

    /**
     *
     * @return string of values in set
     *
     */
    @Override
    public String toString()
    {
        String j = "";
        j = j+lSet;
        return j;
    }
    ListSet()
    {
        lSet= new ArrayList<Integer>();
    }

    void add(int val)
    {
        lSet.add(val);
    }

    int removePos(int pos)
    {
        return lSet.remove(pos);
    }

    boolean contains(int val)
    {
        if(lSet.contains(val))
        {
            return true;
        }
        else{return false;}
    }

    int getSize()
    {
        return lSet.size();
    }

}
