package Connect4Game;
/*
    James Foster
    jaf2@clemson.edu
    CPSC 2150
    HomeWork 2
 */

import java.util.*;

public class Connect4Game {

    public static void main(String [] args)
    {
        GameBoard board;
        Scanner scanner = new Scanner((System.in));
        String clearBuff;
        int input;
        char piece;
        String nGame = "Y";

        //while loop to play game
        while(nGame.equals("y")||nGame.equals("Y")) {

            //at start of game set piece to plat next to X
            piece = 'X';
            int row=-1, col=-1, howManyToWin=-1;
            int win=0;

            //while loop to ask for number of rows and check for valid number
            while(row<3 || row>100) {
                System.out.println("How many rows should be on the board?");
                row=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(row<3) {System.out.println("Must have at least 3 rows");}
                else if(row>100){ System.out.println("Can have at most 100 rows");}
            }

            //while loop to ask for number of rows and check for valid number
            while(col<3 || col>100) {
                System.out.println("How many columns should be on the board?");
                col=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(col<3) {System.out.println("Must have at least 3 columns");}
                else if (col>100){System.out.println("Can have at most 100 columns");}
            }

            //while loop to ask for number of rows and check for valid number
            while(howManyToWin<3||howManyToWin>25) {
                System.out.println("How many in a row to win?");
                howManyToWin=scanner.nextInt();
                clearBuff = scanner.nextLine();
                if(howManyToWin<3){ System.out.println("Must have at least 3 in a row to win");}
                else if(howManyToWin>25){System.out.println("Can have at most 25 in a row to win");}
                else if(howManyToWin>col&&howManyToWin>row)
                {
                    System.out.println("Not possible to win with size of board");
                    howManyToWin = -1;
                }
            }

            //create new game board with new rows and columns
            board = new GameBoard(row, col, howManyToWin);
            System.out.println(board.toString());
            int piecesToUse = board.getNumRows() * board.getNumColumns();

            //loops through players till either a win apears or there are no more pieces to be played
            while (piecesToUse > 0) {
                //Player X
                while (piece == 'X' && piecesToUse>0) {
                    System.out.println("Player X, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();

                    //verify user input
                    while (input < 0 || input >board.getNumColumns()-1) {
                        System.out.println("Column must be between 0 and " + (board.getNumColumns()-1));
                        System.out.println("Player X, what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                    }

                    //confirm column desired is not full
                    while (!board.checkIfFree(input)) {
                        System.out.println("Column is full");
                        System.out.println("Player X, what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                    }

                    board.placeToken('X', input);

                    //checks for win
                    if (board.checkForWin(input)) {
                        System.out.println(board.toString());
                        System.out.println("Player X Won!");

                        win = 1;
                        int i = 0;

                        //if won, asks to play again
                        while (i != 1) {
                            System.out.println("Would you like to play again?  Y/N");
                            nGame = scanner.nextLine();
                            if (nGame.equals("y") || nGame.equals("Y")) {
                                i = 1;
                                piecesToUse =0;
                            }
                            else if (nGame.equals("n") || nGame.equals("N"))
                            { System.exit(0); }
                        }
                    }
                    //if no win print board after piece has been placed and switch player
                    else {
                        System.out.println(board.toString());
                        piece = 'O';
                        piecesToUse--;
                    }

                }

                //Player O
                while (piece =='O' && piecesToUse>0){
                    System.out.println("Player O, what column do you want to place your marker in?");
                    input = scanner.nextInt();
                    clearBuff = scanner.nextLine();

                    //verify user input
                    while (input < 0 || input >board.getNumColumns()-1) {
                        System.out.println("Column must be between 0 and " + (board.getNumColumns()-1));
                        System.out.println("Player O, what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                    }

                    //make sure desired column isn't full
                    while (!board.checkIfFree(input)) {
                        System.out.println("Column is full");
                        System.out.println("Player O, what column do you want to place your marker in?");
                        input = scanner.nextInt();
                        clearBuff = scanner.nextLine();
                    }

                    board.placeToken('O', input);

                    //checks for win
                    if (board.checkForWin(input)) {
                        System.out.println(board.toString());
                        System.out.println("Player O Won!");

                        win = 1;
                        int i = 0;
                        //if win then asks to play again
                        while (i != 1) {
                            System.out.println("Would you like to play again?  Y/N");
                            nGame = scanner.nextLine();
                            if (nGame.equals("y") || nGame.equals("Y")) {
                                i = 1;
                                piecesToUse=0;
                            }
                            else if (nGame.equals("n") || nGame.equals("N"))
                            {System.exit(0);}
                        }
                    }

                    //if no win print board after piece has been placed and switch player
                    else {
                        System.out.println(board.toString());
                        piece = 'X';
                        piecesToUse--;
                    }

                }
            }
            //after all pieces are played, check for tie and asks to play again
            if (board.checkTie() && win!=1) {
                System.out.println("Tie game");
                System.out.println("Would you like to play again?  Y/N");
                nGame = scanner.nextLine();
            }
        }
        System.exit(0);
    }
}
